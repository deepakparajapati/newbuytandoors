package com.buytandoors.webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuytandoorsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
