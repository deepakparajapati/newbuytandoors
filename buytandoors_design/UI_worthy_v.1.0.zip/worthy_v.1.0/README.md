Worthy - Free Bootstrap Template
=======================================================================

Worhty is a Multipurpose One Page Template based on Bootstrap 3 Framework. 
You can use it for corporate, business and agency webpages as well as 
portfolio and personal webpages.

If you like the template and find it useful, please help us spread the word :-)

- Theme version: v1.0
- Release Date: 13 Nov 2014
- Author: HtmlCoder (http://htmlcoder.me)
- Contact: http://htmlcoder.me/contact

Live Preview
=======================================================================
http://www.htmlcoder.me/preview/worthy/v.1.0

License
=======================================================================
Worthy is released under the Creative Commons Attribution 3.0 License
https://creativecommons.org/licenses/by/3.0/

Credits
=======================================================================

Demo images
------------------------------------------------------
- Unsplash by Crew - http://unsplash.com/

Fonts
------------------------------------------------------
- Font Awesome by Dave Gandy - http://fortawesome.github.io/Font-Awesome/
- Google Fonts - http://www.google.com/fonts

Resources
------------------------------------------------------
- Bootstrap Framework by @mdo and @fat - http://getbootstrap.com/
- jQuery - https://jquery.org/
- jQuery Appear - by bas2k - https://github.com/bas2k/jquery.appear/
- Modernizr - http://modernizr.com/
- Animate CSS by Daniel T. Eden - http://daneden.github.io/animate.css/
- Isotope Jquery plugin by metafizzy.co - http://isotope.metafizzy.co/
- Backstrech by Scott Robbin - http://srobbin.com/jquery-plugins/backstretch/
